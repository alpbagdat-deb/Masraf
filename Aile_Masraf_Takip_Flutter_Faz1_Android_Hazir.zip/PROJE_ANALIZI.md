# Aile Masraf Takip — Proje Özeti

## Amaç
Ailenin günlük giderlerini hızlıca kaydetmek; gideri ödeyen kişi ile giderin kimin için yapıldığını ayırmak; kategori, kişi, hafta ve ay bazında raporlamak. İlk sürüm OnePlus 13 üzerinde tamamen yerel çalışır.

## Ürünlerden alınan iyi fikirler
- Money Manager: hızlı fiş/masraf girişi, haftalık ve aylık görünüm, kategori bütçesi, grafik/rapor.
- Wallet by BudgetBakers: hızlı kayıt, fiş yakalama ve çevrim dışı kullanıma yönelik yaklaşım.
- Spendee: ortak cüzdan ve birden fazla kişinin aynı aile harcamalarını görmesi.
- Goodbudget: aile bütçesini kategorilere bölerek izleme.

Kaynaklar: https://www.realbyteapps.com/ ; https://budgetbakers.com/en/products/wallet/download/ ; https://help.spendee.com/article/224-shared-wallets

## Veri modeli
Expense: id, amount, date, shop, category, payerId, beneficiaryId, note, createdAt.
Member: id, name, role.
Settings: aylık bütçe gibi cihaz ayarları.

Önemli kural: `payerId` ödemeyi yapan kişidir; `beneficiaryId` harcamanın kimin için yapıldığını belirtir. Örneğin anne 1. çocuğun kursunu öderse ödeyen=Anne, masraf sahibi=1. çocuk.

## Faz 1 — Temel özellikler
- Yerel SQLite; internet ve hesap gerektirmez.
- Masraf ekleme, listeleme, arama ve silme.
- Kategori, dükkan, tarih, tutar, not, ödeyen ve masraf sahibi.
- Haftalık/aylık toplamlar, kategori raporu, kişi bazlı rapor.
- Aylık aile bütçesi ve bütçe kullanım çubuğu.
- Fotoğraf, OCR, uzak DB ve cihazlar arası senkronizasyon bu fazda yok.

## Faz 2 — Fotoğraf ve akıllı tarama
- Kamera ve galeriden fiş/fatura ekleme.
- Görseli yerel saklama.
- OCR ile işyeri, tarih, genel toplam ve mümkünse satır kalemlerini çıkarma.
- Kategori için kural tabanlı öneri; düşük güvenli sonuçları kullanıcıya onaylatma.
- OCR hatalı okuyabileceğinden hiçbir tutarı sessizce kesinleştirmeme.

## Faz 3 — Canlı DB ve senkronizasyon
- Aile sahibi hesabı ve davetle üye ekleme.
- Kullanıcı oturumu ve aileye göre erişim kuralları.
- İlk tercih: ücretsiz kotası bulunan Supabase (PostgreSQL + Auth + Row Level Security); fotoğraflar için sınırlı Storage kotası. Ücretsiz planların kotası ve koşulları değişebileceğinden uygulama yayına alınmadan önce doğrulanmalı. Alternatif: Firebase Authentication + Firestore.
- Yerel SQLite kayıt kaynağı olarak kalır; çevrim dışı işlemler `pending` kuyruğuna yazılır.
- Bağlantı gelince artımlı gönderim/indirme, idempotent işlem kimliği ve son güncelleme bilgisiyle senkronizasyon.
- Çakışma stratejisi: yeni masraflar UUID ile ayrılır; düzenleme/silme için `updatedAt` ve silme işareti tutulur; çakışmalar sessizce kaybolmaz.
- RLS ile aile üyeleri yalnızca kendi aile alanını görür. API anahtarları, servis rolü veya yönetici sırları APK içine gömülmez.
- Kullanıcı kaldırma, veri dışa aktarma ve yedekleme seçenekleri.

## Güvenlik ve sınırlar
- Faz 1'de veriler yalnızca bu cihazdadır; uygulamayı kaldırmak veya cihazı kaybetmek veri kaybına yol açabilir. Düzenli dışa aktarma/yerel yedek sonraki iyileştirme olarak önerilir.
- Faz 1 aile üyeleri uygulama içinde raporlamaya yarayan profillerdir; ayrı oturum açma sağlamaz.
- Faz 2 OCR sonuçları öneridir; kullanıcı kontrol eder.
- Faz 3'te kimlik doğrulama, aile kapsamı ve veritabanı erişim kuralları yayına çıkmadan test edilmelidir.
