# GitHub ve Codemagic ile APK üretme (telefondan)

1. Bu ZIP'i açıp içindeki proje dosyalarını GitHub deposunun kök dizinine yükleyin. ZIP dosyasını tek başına depoda bırakmak yeterli değildir.
2. Depo kökünde `pubspec.yaml`, `lib/main.dart` ve `android/` klasörü görünmelidir.
3. Codemagic'te GitHub deposunu seçin.
4. Android/Flutter build ayarlarında release APK üretimini seçin. Gerekirse `flutter pub get` ve `flutter build apk --release` komutlarını çalıştırın.
5. Başarılı derlemede artifact bölümünden APK'yı indirin.

Not: Bu paket kaynak projeyi ve Android Gradle iskeletini içerir; APK'nın başarıyla derlendiği bu ortamda doğrulanmamıştır.
