import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ExpenseDb.instance.init();
  runApp(const FamilyExpenseApp());
}

const categories = <String>['Mutfak', 'Eğitim', 'Seyahat', 'Sağlık', 'Giyim', 'Araç', 'Fatura', 'Ev', 'Diğer'];
final money = NumberFormat.currency(locale: 'tr_TR', symbol: '₺', decimalDigits: 2);
final dateFmt = DateFormat('dd.MM.yyyy', 'tr_TR');

class ExpenseDb {
  ExpenseDb._();
  static final instance = ExpenseDb._();
  Database? _db;
  Database get db => _db!;

  Future<void> init() async {
    final base = await getDatabasesPath();
    _db = await openDatabase(p.join(base, 'aile_masraf_takip.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE members(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, role TEXT NOT NULL DEFAULT 'Aile üyesi')''');
        await db.execute('''CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL NOT NULL, date TEXT NOT NULL, shop TEXT NOT NULL, category TEXT NOT NULL, payerId INTEGER NOT NULL, beneficiaryId INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', createdAt TEXT NOT NULL)''');
        await db.execute('''CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
        await db.insert('members', {'name': 'Ben', 'role': 'Yönetici'});
        await db.insert('settings', {'key': 'monthlyBudget', 'value': '0'});
      },
    );
  }

  Future<List<Map<String, Object?>>> members() => db.query('members', orderBy: 'id');
  Future<int> addMember(String name) => db.insert('members', {'name': name.trim(), 'role': 'Aile üyesi'}, conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<int> addExpense(Map<String, Object?> data) => db.insert('expenses', data);
  Future<int> deleteExpense(int id) => db.delete('expenses', where: 'id = ?', whereArgs: [id]);
  Future<List<Map<String, Object?>>> expenses({DateTime? from, DateTime? to}) async {
    String? where; List<Object?> args = [];
    if (from != null && to != null) {
      where = 'date >= ? AND date <= ?';
      args = [DateFormat('yyyy-MM-dd').format(from), DateFormat('yyyy-MM-dd').format(to)];
    }
    return db.rawQuery('''SELECT e.*, p.name AS payerName, b.name AS beneficiaryName FROM expenses e LEFT JOIN members p ON p.id=e.payerId LEFT JOIN members b ON b.id=e.beneficiaryId ${where == null ? '' : 'WHERE $where'} ORDER BY e.date DESC, e.id DESC''', args);
  }
  Future<double> budget() async {
    final rows = await db.query('settings', where: 'key=?', whereArgs: ['monthlyBudget']);
    return double.tryParse(rows.isEmpty ? '0' : (rows.first['value'] as String? ?? '0')) ?? 0;
  }
  Future<void> setBudget(double value) => db.insert('settings', {'key': 'monthlyBudget', 'value': value.toString()}, conflictAlgorithm: ConflictAlgorithm.replace);
}

class FamilyExpenseApp extends StatelessWidget {
  const FamilyExpenseApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Aile Masraf Takip', debugShowCheckedModeBanner: false,
    locale: const Locale('tr', 'TR'), supportedLocales: const [Locale('tr', 'TR')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF356859)), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF5F7F4), cardTheme: const CardThemeData(elevation: 0, color: Colors.white, margin: EdgeInsets.zero)),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  int tab = 0; String period = 'Ay'; DateTime now = DateTime.now();
  Future<void> refresh() async { if (mounted) setState(() {}); }
  DateTime get from => period == 'Hafta' ? DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1)) : DateTime(now.year, now.month, 1);
  DateTime get to => period == 'Hafta' ? from.add(const Duration(days: 6)) : DateTime(now.year, now.month + 1, 0);
  @override Widget build(BuildContext context) {
    final pages = [dashboard(), const ExpensesPage(), const ReportsPage(), const FamilyPage()];
    return Scaffold(body: SafeArea(child: pages[tab]), floatingActionButton: tab == 0 || tab == 1 ? FloatingActionButton.extended(onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddExpensePage())); await refresh(); }, icon: const Icon(Icons.add), label: const Text('Masraf ekle')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Özet'), NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Masraflar'), NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Raporlar'), NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Aile')]),
    );
  }
  Widget dashboard() => FutureBuilder<List<dynamic>>(future: Future.wait([ExpenseDb.instance.expenses(from: from, to: to), ExpenseDb.instance.budget(), ExpenseDb.instance.members()]), builder: (context, snap) {
    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
    final rows = snap.data![0] as List<Map<String,Object?>>; final budget = snap.data![1] as double; final members = snap.data![2] as List<Map<String,Object?>>;
    final total = rows.fold<double>(0, (s, r) => s + ((r['amount'] as num?)?.toDouble() ?? 0));
    final todayTotal = rows.where((r) => r['date'] == DateFormat('yyyy-MM-dd').format(now)).fold<double>(0, (s,r) => s + ((r['amount'] as num?)?.toDouble() ?? 0));
    return RefreshIndicator(onRefresh: refresh, child: ListView(padding: const EdgeInsets.fromLTRB(20, 20, 20, 100), children: [
      const Text('Aile bütçesi', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)), const SizedBox(height: 4), const Text('Harcamalarınız tek yerde.', style: TextStyle(color: Colors.black54)), const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: const Color(0xFF356859), borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Expanded(child: Text('Toplam harcama', style: TextStyle(color: Colors.white70))), SegmentedButton<String>(style: const ButtonStyle(visualDensity: VisualDensity.compact), segments: const [ButtonSegment(value: 'Hafta', label: Text('Hafta')), ButtonSegment(value: 'Ay', label: Text('Ay'))], selected: {period}, onSelectionChanged: (v) => setState(() => period = v.first))]), const SizedBox(height: 12), Text(money.format(total), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text('${dateFmt.format(from)} – ${dateFmt.format(to)}', style: const TextStyle(color: Colors.white70)), const SizedBox(height: 20), Row(children: [Expanded(child: _miniStat('Bugün', money.format(todayTotal))), Expanded(child: _miniStat('Kayıt sayısı', '${rows.length}'))])]),
      const SizedBox(height: 16), if (budget > 0) _budgetCard(total, budget), Row(children: [const Expanded(child: Text('Son masraflar', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), TextButton(onPressed: () => setState(() => tab = 1), child: const Text('Tümünü gör'))]),
      if (rows.isEmpty) const _EmptyCard(text: 'Henüz masraf kaydı yok. İlk masrafınızı ekleyin.') else ...rows.take(5).map((r) => _ExpenseTile(row: r, onDelete: () async { await ExpenseDb.instance.deleteExpense(r['id'] as int); await refresh(); })),
      const SizedBox(height: 14), Row(children: [const Icon(Icons.people_alt_outlined, color: Color(0xFF356859)), const SizedBox(width: 8), Text('${members.length} aile üyesi kayıtlı')]),
    ]));
  });
  Widget _miniStat(String title, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 5), Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))]);
  Widget _budgetCard(double total, double budget) { final ratio = (total / budget).clamp(0.0, 1.0); return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Expanded(child: Text('Aylık bütçe', style: TextStyle(fontWeight: FontWeight.bold))), Text('${(ratio*100).round()}%')]), const SizedBox(height: 10), LinearProgressIndicator(value: ratio, minHeight: 8, borderRadius: BorderRadius.circular(8)), const SizedBox(height: 8), Text('${money.format(total)} / ${money.format(budget)}'), if (total > budget) const Text('Bütçe aşıldı.', style: TextStyle(color: Colors.red))]))); }
}

class AddExpensePage extends StatefulWidget { const AddExpensePage({super.key}); @override State<AddExpensePage> createState() => _AddExpensePageState(); }
class _AddExpensePageState extends State<AddExpensePage> {
  final form = GlobalKey<FormState>(); final amount = TextEditingController(); final shop = TextEditingController(); final note = TextEditingController();
  String category = categories.first; DateTime date = DateTime.now(); int? payer, beneficiary; List<Map<String,Object?>> members = []; bool saving = false;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { members = await ExpenseDb.instance.members(); if (members.isNotEmpty) { payer = members.first['id'] as int; beneficiary = payer; } if (mounted) setState(() {}); }
  @override void dispose() { amount.dispose(); shop.dispose(); note.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Yeni masraf')), body: members.isEmpty ? const Center(child: CircularProgressIndicator()) : Form(key: form, child: ListView(padding: const EdgeInsets.all(20), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFFE4F0E9), borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Tutar', style: TextStyle(fontWeight: FontWeight.w600)), TextFormField(controller: amount, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(hintText: '0,00', suffixText: '₺', border: InputBorder.none), style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold), validator: (v) { final x = double.tryParse((v ?? '').replaceAll(',', '.')); return x == null || x <= 0 ? 'Geçerli bir tutar girin' : null; })])), const SizedBox(height: 18),
    _label('Dükkan / kurum'), TextFormField(controller: shop, decoration: const InputDecoration(hintText: 'Örn. Market, okul, servis', prefixIcon: Icon(Icons.store_outlined), border: OutlineInputBorder()), validator: (v) => (v == null || v.trim().isEmpty) ? 'Dükkan veya kurum adını girin' : null), const SizedBox(height: 16),
    _label('Masraf kategorisi'), DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(border: OutlineInputBorder()), items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (v) => setState(() => category = v ?? categories.first)), const SizedBox(height: 16),
    _label('Ödemeyi yapan'), DropdownButtonFormField<int>(value: payer, decoration: const InputDecoration(border: OutlineInputBorder()), items: members.map((m) => DropdownMenuItem(value: m['id'] as int, child: Text(m['name'] as String))).toList(), onChanged: (v) => setState(() => payer = v)), const SizedBox(height: 16),
    _label('Masraf kimin için?'), DropdownButtonFormField<int>(value: beneficiary, decoration: const InputDecoration(border: OutlineInputBorder()), items: members.map((m) => DropdownMenuItem(value: m['id'] as int, child: Text(m['name'] as String))).toList(), onChanged: (v) => setState(() => beneficiary = v)), const SizedBox(height: 16),
    _label('Tarih'), OutlinedButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2015), lastDate: DateTime(2100), locale: const Locale('tr','TR')); if (d != null) setState(() => date = d); }, icon: const Icon(Icons.calendar_month), label: Text(dateFmt.format(date)), style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16), alignment: Alignment.centerLeft)), const SizedBox(height: 16),
    _label('Not (isteğe bağlı)'), TextFormField(controller: note, maxLines: 2, decoration: const InputDecoration(hintText: 'Ek açıklama', border: OutlineInputBorder())), const SizedBox(height: 24),
    FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save_outlined), label: Padding(padding: const EdgeInsets.symmetric(vertical: 14), child: Text(saving ? 'Kaydediliyor…' : 'Masrafı kaydet'))), const SizedBox(height: 8), const Center(child: Text('Bu sürümde kayıtlar yalnızca bu cihazda saklanır.', style: TextStyle(fontSize: 12, color: Colors.black54)))
  ])));
  Widget _label(String t) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Text(t, style: const TextStyle(fontWeight: FontWeight.w600)));
  Future<void> save() async { if (!form.currentState!.validate() || payer == null || beneficiary == null) return; setState(() => saving = true); await ExpenseDb.instance.addExpense({'amount': double.parse(amount.text.replaceAll(',', '.')), 'date': DateFormat('yyyy-MM-dd').format(date), 'shop': shop.text.trim(), 'category': category, 'payerId': payer, 'beneficiaryId': beneficiary, 'note': note.text.trim(), 'createdAt': DateTime.now().toIso8601String()}); if (mounted) Navigator.pop(context, true); }
}

class ExpensesPage extends StatefulWidget { const ExpensesPage({super.key}); @override State<ExpensesPage> createState() => _ExpensesPageState(); }
class _ExpensesPageState extends State<ExpensesPage> { String period = 'Ay'; String search = ''; @override Widget build(BuildContext context) { final now = DateTime.now(); final from = period == 'Hafta' ? DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday-1)) : DateTime(now.year,now.month,1); final to = period == 'Hafta' ? from.add(const Duration(days: 6)) : DateTime(now.year,now.month+1,0); return Scaffold(appBar: AppBar(title: const Text('Masraflar')), body: Column(children: [Padding(padding: const EdgeInsets.fromLTRB(16,8,16,8), child: Column(children: [TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Dükkan, kategori veya kişi ara', border: OutlineInputBorder()), onChanged: (v) => setState(() => search = v.toLowerCase())), const SizedBox(height: 10), SegmentedButton<String>(expanded: true, segments: const [ButtonSegment(value: 'Hafta', label: Text('Bu hafta')), ButtonSegment(value: 'Ay', label: Text('Bu ay'))], selected: {period}, onSelectionChanged: (s) => setState(() => period = s.first))])), Expanded(child: FutureBuilder<List<Map<String,Object?>>>(future: ExpenseDb.instance.expenses(from: from,to: to), builder: (context,snap) { if (!snap.hasData) return const Center(child: CircularProgressIndicator()); final rows = snap.data!.where((r) => '${r['shop']} ${r['category']} ${r['payerName']} ${r['beneficiaryName']} ${r['note']}'.toLowerCase().contains(search)).toList(); if (rows.isEmpty) return const _EmptyCard(text: 'Bu dönemde eşleşen masraf bulunamadı.'); return ListView.separated(padding: const EdgeInsets.fromLTRB(16,4,16,100), itemCount: rows.length, separatorBuilder: (_,__) => const SizedBox(height: 8), itemBuilder: (_,i) => _ExpenseTile(row: rows[i], onDelete: () async { await ExpenseDb.instance.deleteExpense(rows[i]['id'] as int); setState(() {}); })); }))])); } }

class ReportsPage extends StatefulWidget { const ReportsPage({super.key}); @override State<ReportsPage> createState() => _ReportsPageState(); }
class _ReportsPageState extends State<ReportsPage> { String period = 'Ay'; @override Widget build(BuildContext context) { final now=DateTime.now(); final from=period=='Hafta'?DateTime(now.year,now.month,now.day).subtract(Duration(days:now.weekday-1)):DateTime(now.year,now.month,1); final to=period=='Hafta'?from.add(const Duration(days:6)):DateTime(now.year,now.month+1,0); return Scaffold(appBar: AppBar(title: const Text('Raporlar')), body: FutureBuilder<List<dynamic>>(future: Future.wait([ExpenseDb.instance.expenses(from:from,to:to),ExpenseDb.instance.members()]), builder: (context,snap) { if(!snap.hasData)return const Center(child:CircularProgressIndicator()); final rows=snap.data![0] as List<Map<String,Object?>>; final members=snap.data![1] as List<Map<String,Object?>>; final total=rows.fold<double>(0,(s,r)=>s+((r['amount'] as num).toDouble())); final cats=<String,double>{}; for(final r in rows){ final c=r['category'] as String; cats[c]=(cats[c]??0)+(r['amount'] as num).toDouble(); } final sorted=cats.entries.toList()..sort((a,b)=>b.value.compareTo(a.value)); return ListView(padding: const EdgeInsets.all(18), children: [SegmentedButton<String>(expanded:true,segments:const [ButtonSegment(value:'Hafta',label:Text('Haftalık')),ButtonSegment(value:'Ay',label:Text('Aylık'))],selected:{period},onSelectionChanged:(s)=>setState(()=>period=s.first)), const SizedBox(height:16), Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Toplam harcama',style:TextStyle(color:Colors.black54)),const SizedBox(height:6),Text(money.format(total),style:const TextStyle(fontSize:30,fontWeight:FontWeight.bold)),Text('${rows.length} işlem',style:const TextStyle(color:Colors.black54))]))), const SizedBox(height:18), const Text('Kategori dağılımı',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)), const SizedBox(height:8), if(sorted.isEmpty) const _EmptyCard(text:'Henüz rapor oluşturacak veri yok.') else ...sorted.map((e)=>_ReportRow(label:e.key,amount:e.value,total:total)), const SizedBox(height:18), const Text('Kişi bazlı masraf',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)), const SizedBox(height:8), ...members.map((m){ final id=m['id']; final paid=rows.where((r)=>r['payerId']==id).fold<double>(0,(s,r)=>s+(r['amount'] as num).toDouble()); final forPerson=rows.where((r)=>r['beneficiaryId']==id).fold<double>(0,(s,r)=>s+(r['amount'] as num).toDouble()); return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(m['name'] as String,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:6),Row(children:[Expanded(child:Text('Ödedi: ${money.format(paid)}')),Expanded(child:Text('Onun için: ${money.format(forPerson)}'))])]))); })]); } }); } }

class FamilyPage extends StatefulWidget { const FamilyPage({super.key}); @override State<FamilyPage> createState()=>_FamilyPageState(); }
class _FamilyPageState extends State<FamilyPage> { final name=TextEditingController(); final budget=TextEditingController(); @override void dispose(){name.dispose();budget.dispose();super.dispose();} @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Aile üyeleri')),body:FutureBuilder<List<dynamic>>(future:Future.wait([ExpenseDb.instance.members(),ExpenseDb.instance.budget()]),builder:(context,snap){if(!snap.hasData)return const Center(child:CircularProgressIndicator()); final members=snap.data![0] as List<Map<String,Object?>>; final b=snap.data![1] as double; budget.text= b==0?'':b.toStringAsFixed(2); return ListView(padding:const EdgeInsets.all(18),children:[const Text('Aile üyeleri',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:8),...members.map((m)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person_outline)),title:Text(m['name'] as String),subtitle:Text(m['role'] as String)))),const SizedBox(height:12),FilledButton.tonalIcon(onPressed:()async{ name.clear(); final v=await showDialog<String>(context:context,builder:(c)=>AlertDialog(title:const Text('Aile üyesi ekle'),content:TextField(controller:name,autofocus:true,decoration:const InputDecoration(hintText:'Adı')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('İptal')),FilledButton(onPressed:()=>Navigator.pop(c,name.text.trim()),child:const Text('Ekle'))])); if(v!=null&&v.trim().isNotEmpty){await ExpenseDb.instance.addMember(v);setState((){});} },icon:const Icon(Icons.person_add_alt),label:const Text('Aile üyesi ekle')),const SizedBox(height:24),const Text('Aylık aile bütçesi',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:8),TextField(controller:budget,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(prefixIcon:Icon(Icons.account_balance_wallet_outlined),suffixText:'₺',hintText:'Bütçe tutarı',border:OutlineInputBorder())),const SizedBox(height:10),FilledButton(onPressed:()async{final v=double.tryParse(budget.text.replaceAll(',','.'))??0;await ExpenseDb.instance.setBudget(v);if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Aylık bütçe kaydedildi')));setState((){});},child:const Text('Bütçeyi kaydet')),const SizedBox(height:20),const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('Faz 1: Üyeler aynı cihazdaki kayıtları kişi bazında ayırır. Farklı cihazlarda ayrı giriş ve çevrim içi senkronizasyon Faz 3 kapsamında eklenecektir.')))]);} }

class _ExpenseTile extends StatelessWidget { final Map<String,Object?> row; final VoidCallback onDelete; const _ExpenseTile({required this.row,required this.onDelete}); @override Widget build(BuildContext context){ final amount=(row['amount'] as num?)?.toDouble()??0; return Card(child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:5),leading:Container(width:44,height:44,decoration:BoxDecoration(color:const Color(0xFFE4F0E9),borderRadius:BorderRadius.circular(14)),child:Icon(_iconFor(row['category'] as String? ?? ''),color:const Color(0xFF356859))),title:Text(row['shop'] as String? ?? 'Masraf',style:const TextStyle(fontWeight:FontWeight.w700),maxLines:1,overflow:TextOverflow.ellipsis),subtitle:Text('${row['category']} · ${row['beneficiaryName'] ?? '—'} için\n${dateFmt.format(DateTime.tryParse(row['date'] as String? ?? '')??DateTime.now())} · Ödeyen: ${row['payerName']??'—'}',maxLines:2,overflow:TextOverflow.ellipsis),isThreeLine:true,trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Flexible(child:Text(money.format(amount),style:const TextStyle(fontWeight:FontWeight.bold))),IconButton(visualDensity:VisualDensity.compact,tooltip:'Sil',onPressed:()=>showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Masraf silinsin mi?'),content:const Text('Bu işlem cihazdaki kayıtlardan silinecek.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Vazgeç')),FilledButton(onPressed:(){Navigator.pop(c);onDelete();},child:const Text('Sil'))])),icon:const Icon(Icons.delete_outline,size:19))]))); } }
IconData _iconFor(String c)=>switch(c){'Mutfak'=>Icons.restaurant_outlined,'Eğitim'=>Icons.school_outlined,'Seyahat'=>Icons.flight_takeoff_outlined,'Sağlık'=>Icons.medical_services_outlined,'Giyim'=>Icons.checkroom_outlined,'Araç'=>Icons.directions_car_outlined,'Fatura'=>Icons.receipt_long_outlined,'Ev'=>Icons.home_outlined,_=>Icons.shopping_bag_outlined};
class _EmptyCard extends StatelessWidget { final String text; const _EmptyCard({required this.text}); @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Icon(Icons.receipt_long_outlined,size:38,color:Colors.black38),const SizedBox(height:10),Text(text,textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54))]))); }
class _ReportRow extends StatelessWidget { final String label; final double amount,total; const _ReportRow({required this.label,required this.amount,required this.total}); @override Widget build(BuildContext context){final ratio=total==0?0.0:(amount/total).clamp(0.0,1.0);return Padding(padding:const EdgeInsets.only(bottom:14),child:Column(children:[Row(children:[Expanded(child:Text(label)),Text(money.format(amount),style:const TextStyle(fontWeight:FontWeight.w600))]),const SizedBox(height:6),LinearProgressIndicator(value:ratio,minHeight:7,borderRadius:BorderRadius.circular(8))]));} }
