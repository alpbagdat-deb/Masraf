package com.example.aile_masraf_takip

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
