# Aile Masraf Takip — Faz 1

Flutter Android uygulaması. Faz 1'de veriler sadece telefondaki SQLite veritabanında tutulur; fotoğraf, OCR, hesap açma ve bulut senkronizasyonu yoktur.

## Faz 1 özellikleri
- Masraf ekleme: tutar, tarih, dükkan/kurum, kategori, ödeyen, masraf sahibi, not
- Varsayılan kategoriler: Mutfak, Eğitim, Seyahat, Sağlık, Giyim, Araç, Fatura, Ev, Diğer
- Haftalık/aylık toplam ve masraf listesi
- Dükkan, kategori ve kişi metin araması
- Kategori bazlı rapor
- Kişi bazlı rapor: kişinin ödediği ve kendisi için yapılan masraf ayrı ayrı
- Aile üyesi ekleme
- Aylık bütçe ve bütçe kullanım göstergesi
- İnternet olmadan çalışma; yerel SQLite

## Derleme
Flutter 3.29 veya üzeri önerilir. Android SDK ve Android build araçları kurulu olmalıdır.

```bash
flutter pub get
flutter analyze
flutter build apk --release
```
APK yolu: `build/app/outputs/flutter-apk/app-release.apk`

## Faz planı
- Faz 1 — Yerel temel uygulama: bu kaynak kod.
- Faz 2 — Fiş/fatura fotoğrafı: kamera ve galeri, görüntüyü yerelde saklama, OCR ile tarih/işyeri/tutar ve satır kalemi önerisi; kullanıcı onayı olmadan otomatik kayıt yapılmaması.
- Faz 3 — Çok cihazlı aile kullanımı: kimlik doğrulama, güvenli bulut DB, çevrim dışı işlem kuyruğu, çevrim içi olunca senkronizasyon, çakışma yönetimi ve fotoğraf depolama.

## Notlar
Bu kaynak kod burada Flutter/Android SDK bulunmadığı için APK olarak derlenip cihazda test edilmiş değildir. APK üretmek için yukarıdaki Flutter derleme komutlarını çalıştırın. Aile üyeleri Faz 1'de aynı cihazdaki raporlama profilleridir; ayrı kullanıcı girişi Faz 3'te gelir.
